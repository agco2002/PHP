<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reporte</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form class="form" method="post" action="reporte2.php">
    <h1>Generar Reporte</h1>

<input type="text" name="nombre" id="nombre" placeholder="Ingrese Nombre"  >
<br>
<button class="button" type="submit">Generar reporte</button>
</body>
</html>